package edu.umb.cs.hw2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import edu.umb.cs.hw2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
//    var count=0;
    private lateinit var viewModel:MyViewModel
    private lateinit var mybinding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)

        mybinding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        viewModel = ViewModelProvider(this).get(MyViewModel::class.java)

        mybinding.lifecycleOwner = this
        mybinding.viewmodel = viewModel

//        val redvotes=findViewById<TextView>(R.id.redPerc)
//        val bluevotes=findViewById<TextView>(R.id.bluePerc)
//        val greenvotes=findViewById<TextView>(R.id.greenPerc)
//        val orangevotes=findViewById<TextView>(R.id.orangePerc)
//
//        val redbutton =findViewById<Button>(R.id.button)
//        val bluebutton =findViewById<Button>(R.id.button3)
//        val orangebutton =findViewById<Button>(R.id.button2)
//        val greenbutton =findViewById<Button>(R.id.button4)

//        redvotes.text= viewModel.countred.toString()
//        bluevotes.text= viewModel.countred.toString()
//        greenvotes.text =viewModel.countred.toString()
//        orangevotes.text= viewModel.countred.toString()

//        viewModel.countred.observe(this, Observer{
//            redvotes.text = it.toString()
//
//
//        })
//        viewModel.countblue.observe(this, Observer{
//
//            bluevotes.text=it.toString()
//
//
//        })
//        viewModel.countgreen.observe(this, Observer{
//
//            greenvotes.text=it.toString()
//
//
//        })
//        viewModel.countorange.observe(this, Observer{
//
//            orangevotes.text=it.toString()
//
//        })
//
//
////        redbutton.setOnClickListener{
////            viewModel.updateCountRed()
//////            ++ count
//////            redvotes.text= viewModel.count.toString()
////        }
//        orangebutton.setOnClickListener{
//            viewModel.updateCountorange()
////            //orangevotes.text= viewModel.count2.toString()
//        }
//        greenbutton.setOnClickListener{
//            viewModel.updateCountgreen()
////            //greenvotes.text=viewModel.count3.toString()
//        }
//        bluebutton.setOnClickListener{
//            viewModel.updateCountblue()
////            //bluevotes.text=viewModel.count1.toString()
//        }


    }
}