package edu.umb.cs.hw2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MyViewModel:ViewModel() {

//    var count=0
    //var count3=0
    //var count2=0
    // var count1=0

    var total = MutableLiveData<Int?>()
    var countred = MutableLiveData<Int>()
    var countblue = MutableLiveData<Int>()
    var countorange = MutableLiveData<Int>()
    var countgreen = MutableLiveData<Int>()
    var percentageorange = MutableLiveData<Int>()
    var percentagegreen = MutableLiveData<Int>()
    var percentageblue = MutableLiveData<Int>()
    var percentagered = MutableLiveData<Int>()
    var percentagesymbol = MutableLiveData<String>()
    var centvalue = 100;
    var bractet1 = MutableLiveData<String>()
    var bractet2 = MutableLiveData<String>()
    var space = MutableLiveData<String>()
    var dict = MutableLiveData<Map<String, Int?>>()
    var resultfirst = MutableLiveData<String>()
    var resultsecond = MutableLiveData<String>()
    var resultthird = MutableLiveData<String>()
    var resultfourth = MutableLiveData<String>()

    init {
        countred.value = 0;
        countblue.value = 0;
        countorange.value = 0;
        countgreen.value = 0;
        percentagered.value = 0;
        percentageorange.value = 0;
        percentagegreen.value = 0;
        percentageblue.value = 0;
        total.value = 0;
        bractet1.value = "(";
        percentagesymbol.value = "%"
        bractet2.value = ")";
        space.value = " ";
        resultfirst.value = "1 st"
        resultthird.value = "2 nd"
        resultfourth.value = "3 rd"
        resultsecond.value = "4 th"
        dict.value = mapOf(
            "Red" to countred.value,
            "Blue" to countblue.value,
            "Green" to countgreen.value,
            "Orange" to countorange.value
        )
    }

    fun updateCountRed() {
        //++count
        countred.value = (countred.value)?.plus(1)
        total.value = (total.value)?.plus(1)
        getpercentage()
        calldict()
//        dict.value = mapOf(
//            "Red" to countred.value,
//            "Blue" to countblue.value,
//            "Green" to countgreen.value,
//            "Orange" to countorange.value
//        )
//        //dict.value=dict.value?.toSortedMap(compareByDescending { it })
//        //Log.i("muk","${dict.value}")
//        dict()
//        val resultt=dict.value?.toList()?.sortedByDescending { (key, value) -> value}
//        Log.i("muk","${resultt}")
        //percentagered.value= countred.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(100)?.toInt()
//            ((total.value?.let { countred.value?.toFloat()?.div(it.toFloat()) })?.toFloat()?.roundToInt())?.times(100)
        //redpercentage()
//        Log.i("MYTAG","${countred.value}")
//        Log.i("MYTAG","${total.value}")
//        Log.i("MYTAG","${percentagered.value}")
    }

    fun updateCountblue() {
//
//        ++count1
        countblue.value = (countblue.value)?.plus(1)
        total.value = (total.value)?.plus(1)
        getpercentage()
        calldict()
//        dict.value = mapOf(
//            "Red" to countred.value,
//            "Blue" to countblue.value,
//            "Green" to countgreen.value,
//            "Orange" to countorange.value
//        )
//        //Log.i("muk","${dict.value}")
//        //dict.value=dict.value?.toSortedMap(compareByDescending { it })
//        //Log.i("muk","${dict.value}")
//        //percentageblue.value= countblue.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(100)?.toInt()
//        dict()
//        val resultt=dict.value?.toList()?.sortedByDescending { (key, value) -> value}
//        Log.i("muk","${resultt}")
//            ((total.value?.let { countblue.value?.toFloat()?.div(it.toFloat()) })?.toFloat()?.roundToInt())?.times(centvalue)
    }

    fun updateCountorange() {
//
//       ++count2
        countorange.value = (countorange.value)?.plus(1)
        total.value = (total.value)?.plus(1)
        getpercentage()
        calldict()
//        dict.value = mapOf(
//            "Red" to countred.value,
//            "Blue" to countblue.value,
//            "Green" to countgreen.value,
//            "Orange" to countorange.value
//        )
//        //Log.i("muk","${dict.value}")
//        //dict.value=dict.value?.toSortedMap(compareByDescending { it })
//            //Log.i("muk","${dict.value}")
//        dict()
//        val resultt=dict.value?.toList()?.sortedByDescending { (key, value) -> value}
//        Log.i("muk","${resultt}")
        //percentageorange.value= countorange.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(100)?.toInt()
    }

    fun updateCountgreen() {
//       ++count3
        countgreen.value = (countgreen.value)?.plus(1)
        total.value = (total.value)?.plus(1)
        getpercentage()
        calldict()
//        dict.value = mapOf(
//            "Red" to countred.value,
//            "Blue" to countblue.value,
//            "Green" to countgreen.value,
//            "Orange" to countorange.value
//        )
//        dict()
//        val resultt=dict.value?.toList()?.sortedByDescending { (key, value) -> value}
//        Log.i("muk","${resultt?.elementAt(0)?.first}")
        //Log.i("muk","${dict.value}")
        //dict.value=dict.value?.toSortedMap(compareByDescending { it })
        //Log.i("muk","${dict.value}")

        //percentagegreen.value= countgreen.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(100)?.toInt()
    }

    fun calldict() {
        dict.value = mapOf(
            "Red" to countred.value,
            "Blue" to countblue.value,
            "Green" to countgreen.value,
            "Orange" to countorange.value
        )
        dict()
        var resultt = dict.value?.toList()?.sortedByDescending { (key, value) -> value}

        resultfirst.value = "1st " + resultt?.elementAt(0)?.first.toString()
        resultsecond.value = "2nd " + resultt?.elementAt(1)?.first.toString()
        resultthird.value = "3rd " + resultt?.elementAt(2)?.first.toString()
        resultfourth.value = "4th " + resultt?.elementAt(3)?.first.toString()
//        var second = resultt?.
//        Log.i("muk","${resultt?.elementAt(0)?.first}")

    }

    fun getpercentage() {

        //sortdict()
        percentagered.value =
            countred.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(centvalue)?.toInt()
        percentageblue.value =
            countblue.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(centvalue)?.toInt()
        percentageorange.value =
            countorange.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(centvalue)?.toInt()
        percentagegreen.value =
            countgreen.value?.toFloat()?.div(total.value?.toFloat()!!)?.times(centvalue)?.toInt()
    }
//        dict.value=dict.value?.toSortedMap(compareByDescending { it })
//        Log.i("muk","${dict.value}")
//        getpercentage()
//        dict.value=dict.value?.toSortedMap(compareByDescending { it })
//        Log.i("muk","${dict.value}")
//    }
    fun dict(){
        dict.value=dict.value?.toSortedMap(compareByDescending { it })
        //Log.i("muk","${dict.value}")
        //sortdict()
    }




//        val map = mapOf(Pair("Red", countred.value), Pair("Blue", countblue.value), Pair("Green", countgreen.value), Pair("Orange", countorange.value))
//        val sorted = map.toSortedMap()
//        Log.i("MYTAG", "${sorted.values}")
//        println(sorted.keys) // [b, c, d]
//        println(sorted.values) // [2, 3, 1]
}

