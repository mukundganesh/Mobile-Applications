package com.example.homework_fragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clickcf()
        clickfc()
        clickhelp()
    }


    fun clickcf(){
        val input= findViewById<TextView>(R.id.ctof)
        input.setOnClickListener {
            Log.i("mukund","I reached c--f onclick")
            supportFragmentManager.beginTransaction().apply {
                intent.putExtra("input","0")
                supportFragmentManager.beginTransaction().apply { replace(R.id.bottomfragment_call, help()).commit()}
                replace(R.id.bottomfragment_call,BottomFragment()).commit()
            }
        }
    }
    fun clickfc(){
        val input= findViewById<TextView>(R.id.ftoc)
        input.setOnClickListener {
            Log.i("mukund", "I reached f--c onclick")
            supportFragmentManager.beginTransaction().apply {
                intent.putExtra("input","1")
                supportFragmentManager.beginTransaction().apply { replace(R.id.bottomfragment_call, help()).commit()}
                replace(R.id.bottomfragment_call, BottomFragment()).commit()
            }
        }
    }

    fun clickhelp(){
        val input= findViewById<TextView>(R.id.helptextview)
        input.setOnClickListener {
            Log.i("mukund","I reached help onclick")
            supportFragmentManager.beginTransaction().apply {
                intent.putExtra("input","1")
                replace(R.id.bottomfragment_call, help()).commit()
            }
        }
    }


}